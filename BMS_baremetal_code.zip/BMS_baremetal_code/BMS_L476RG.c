/*
 * STM32L476RG bare-metal 3S BMS
 * CMSIS register-level implementation; no HAL/LL calls.
 *
 * Build in STM32CubeIDE with the STM32L476 CMSIS device headers and startup file.
 * Core clock: MSI 4 MHz (reset/default MSI range assumed).
 *
 * IMPORTANT HARDWARE NOTES:
 * 1) STM32L476RG ADC channel mapping used here:
 *      ADC1_IN5 -> PA0 (node B1), IN6 -> PA1 (node B2), IN9 -> PA4 (node B3)
 *      ADC1_IN1 -> PC0 (current), IN2 -> PC1 (NTC).
 *    PA5 / Arduino D13 remains the MOSFET output and LD2 control.
 * 3) Current conversion follows the original assumption: I = ADC voltage / 0.78125 ohm.
 *    This is valid only if the ADC measures the actual voltage across that shunt
 *    with the intended polarity and without an amplifier/offset requiring correction.
 * 4) PA5 is an indicator/control output in the source code, not a safety-rated
 *    battery disconnect. External hardware protection is required.
 */

#include "stm32l476xx.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ---------------- User parameters ---------------- */
#define ADC_MAX                    4095.0f
#define ADC_REF                    3.3f
#define SCALE_B1                   4.4036f
#define SCALE_B2                   3.0373f
#define SCALE_B3                   1.5243f
#define SERIES_RESISTOR            4.116f

#define NTC_FIXED_RESISTOR         10000.0f
#define NTC_NOMINAL_RESISTANCE     10000.0f
#define NTC_NOMINAL_TEMPERATURE    25.0f
#define NTC_BETA                   3950.0f

#define OVER_TEMPERATURE           40.0f
#define TEMPERATURE_RECOVERY       38.0f
#define OVER_CURRENT               0.5f
#define CELL_OVER_VOLTAGE          4.20f
#define CELL_OV_RECOVERY           4.15f
#define CELL_UNDER_VOLTAGE         3.00f
#define CELL_UV_RECOVERY           3.10f

#define BATTERY_CAPACITY_AH        2.0f
#define BATTERY_CAPACITY_C         (BATTERY_CAPACITY_AH * 3600.0f)
#define MODEL_UPDATE_MS            10U
#define MODEL_R0                   0.018504f
#define MODEL_R1                   0.0172f
#define MODEL_C1                   22.7f
#define MODEL_TAU                  (MODEL_R1 * MODEL_C1)

#define UART_BAUD                  115200U
#define SYSCLK_HZ                  4000000U
#define LCD_I2C_ADDR               (0x27U << 1) /* use 0x3F if your backpack requires it */
#define LCD_BACKLIGHT              0x08U
#define LCD_EN                     0x04U
#define LCD_RS                     0x01U
#define SCREEN_BUTTON_PIN          10U /* PA10 / Arduino D2, active-low */

/*
 * ADC channel numbers from the supplied HAL code.
 * Confirm pin mapping and resolve the PA5 / ADC1_IN6 conflict before use.
 */
#define B1_CHANNEL                 5U
#define B2_CHANNEL                 6U
#define B3_CHANNEL                 9U
#define CURRENT_CHANNEL            1U
#define NTC_CHANNEL                2U

#define MOSFET_GPIO                GPIOA
#define MOSFET_PIN                 5U /* Arduino D13 / onboard LD2 */
#define BUTTON_GPIO                GPIOC
#define BUTTON_PIN                 13U

/* ---------------- State ---------------- */
static volatile uint32_t g_ms_ticks;
static volatile uint8_t lcd_screen = 0U;
static volatile uint32_t last_screen_irq_ms = 0U;
static volatile uint32_t last_pc13_irq_ms = 0U;

static volatile bool userToggleState = false;
static bool mosfetState = false;
static bool overTemperatureFault = false;
static bool overCurrentFault = false;
static bool overVoltageFault = false;
static bool underVoltageFault = false;

static float socPack = 100.0f;
static char msg_buffer[256];

static float B1, B2, B3;
static float cell1, cell2, cell3;
static float packVoltage, current, temperature;
static float socCell[3] = {0.0f, 0.0f, 0.0f};
static float vRC[3] = {0.0f, 0.0f, 0.0f};
static float ocvCell[3] = {0.0f, 0.0f, 0.0f};
static float vModel[3] = {0.0f, 0.0f, 0.0f};
static float modelError[3] = {0.0f, 0.0f, 0.0f};
static float modelErrorAbs[3] = {0.0f, 0.0f, 0.0f};
static uint32_t lastModelTime = 0;
static uint32_t lastModelUpdate = 0;
static bool modelInitialized = false;

/* ---------------- Function prototypes ---------------- */
void SystemClock_Config(void);
static void GPIO_Init(void);
static void USART2_Init(void);
static void I2C1_Init(void);
static void LCD_Init(void);
static void LCD_Command(uint8_t cmd);
static void LCD_Data(uint8_t data);
static void LCD_SendNibble(uint8_t nibble, uint8_t rs);
static void LCD_PrintLine(uint8_t row, const char *text);
static void LCD_UpdateScreen(void);
static void LCD_FormatModelError(char *out, size_t out_size,
                                 uint8_t cell_number, float error_v);
static void ADC1_Init(void);
static void ADC_SetChannel(uint32_t channel);
static uint16_t Read_ADC_Channel(uint32_t channel);
static float readBatteryNode(uint32_t channel);
static float readCurrent(uint32_t channel);
static float readTemperature(uint32_t channel);
static float voltageToSOC(float voltage);
static float SOC_to_OCV(float soc);
static void UpdateBatteryModel(float current_A, float dt);
static void UART_SendString(const char *s);
static void delay_ms(uint32_t ms);
static void uart_printf(const char *fmt, ...);

/* ---------------- SysTick ---------------- */
void SysTick_Handler(void)
{
    g_ms_ticks++;
}

void EXTI15_10_IRQHandler(void)
{
    uint32_t pending = EXTI->PR1 & (EXTI_PR1_PIF10 | EXTI_PR1_PIF13);
    uint32_t now = g_ms_ticks;

    if ((pending & EXTI_PR1_PIF10) != 0U) {
        EXTI->PR1 = EXTI_PR1_PIF10;
        if ((uint32_t)(now - last_screen_irq_ms) >= 250U) {
            lcd_screen = (uint8_t)((lcd_screen + 1U) % 4U);
            last_screen_irq_ms = now;
        }
    }

    if ((pending & EXTI_PR1_PIF13) != 0U) {
        EXTI->PR1 = EXTI_PR1_PIF13;
        if ((uint32_t)(now - last_pc13_irq_ms) >= 30U) {
            last_pc13_irq_ms = now;
            userToggleState = !userToggleState;
        }
    }
}

static uint32_t millis(void)
{
    return g_ms_ticks;
}

static void delay_ms(uint32_t ms)
{
    uint32_t start = millis();
    while ((uint32_t)(millis() - start) < ms) {
        __NOP();
    }
}

/* ---------------- Clock ---------------- */
void SystemClock_Config(void)
{
    /* Enable MSI and select 4 MHz range (MSIRANGE = 6). */
    RCC->CR |= RCC_CR_MSION;
    while ((RCC->CR & RCC_CR_MSIRDY) == 0U) {}

    RCC->CR = (RCC->CR & ~RCC_CR_MSIRANGE_Msk) |
              RCC_CR_MSIRANGE_6 | RCC_CR_MSIRGSEL | RCC_CR_MSION;
    while ((RCC->CR & RCC_CR_MSIRDY) == 0U) {}

    /* MSI as SYSCLK, AHB/APB prescalers = /1. */
    RCC->CFGR &= ~(RCC_CFGR_SW_Msk |
                   RCC_CFGR_HPRE_Msk |
                   RCC_CFGR_PPRE1_Msk |
                   RCC_CFGR_PPRE2_Msk);
    RCC->CFGR |= RCC_CFGR_SW_MSI;
    while ((RCC->CFGR & RCC_CFGR_SWS_Msk) != RCC_CFGR_SWS_MSI) {}

    SystemCoreClock = SYSCLK_HZ;
    (void)SysTick_Config(SYSCLK_HZ / 1000U);
}

/* ---------------- GPIO ---------------- */
static void GPIO_Init(void)
{
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN |
                    RCC_AHB2ENR_GPIOBEN |
                    RCC_AHB2ENR_GPIOCEN;
    (void)RCC->AHB2ENR;

    /* PA5 / Arduino D13 MOSFET-control output; LD2 follows it too. */
    MOSFET_GPIO->MODER &= ~(3UL << (MOSFET_PIN * 2U));
    MOSFET_GPIO->MODER |=  (1UL << (MOSFET_PIN * 2U));
    MOSFET_GPIO->OTYPER &= ~(1UL << MOSFET_PIN);
    MOSFET_GPIO->OSPEEDR &= ~(3UL << (MOSFET_PIN * 2U));
    MOSFET_GPIO->PUPDR &= ~(3UL << (MOSFET_PIN * 2U));
    MOSFET_GPIO->BSRR = (1UL << (MOSFET_PIN + 16U));

    /* PC13 button input, no internal pull as in original code. */
    BUTTON_GPIO->MODER &= ~(3UL << (BUTTON_PIN * 2U));
    BUTTON_GPIO->PUPDR &= ~(3UL << (BUTTON_PIN * 2U));

/* ADC1_IN5=PA0, IN6=PA1, IN9=PA4, IN1=PC0, IN2=PC1.
     * STM32L476 requires the GPIO analog switches in ASCR as well. */
    GPIOA->MODER |= (3UL << 0U) | (3UL << 2U) | (3UL << 8U);
    GPIOA->PUPDR &= ~((3UL << 0U) | (3UL << 2U) | (3UL << 8U));
    GPIOC->MODER |= (3UL << 0U) | (3UL << 2U);
    GPIOC->PUPDR &= ~((3UL << 0U) | (3UL << 2U));
    GPIOA->ASCR |= (1UL << 0U) | (1UL << 1U) | (1UL << 4U);
    GPIOC->ASCR |= (1UL << 0U) | (1UL << 1U);

    /* Separate active-low screen button: PA10 / Arduino D2. */
    GPIOA->MODER &= ~(3UL << (SCREEN_BUTTON_PIN * 2U));
    GPIOA->PUPDR &= ~(3UL << (SCREEN_BUTTON_PIN * 2U));
    GPIOA->PUPDR |=  (1UL << (SCREEN_BUTTON_PIN * 2U));
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
    (void)RCC->APB2ENR;
    SYSCFG->EXTICR[2] &= ~SYSCFG_EXTICR3_EXTI10_Msk;
    SYSCFG->EXTICR[2] |= SYSCFG_EXTICR3_EXTI10_PA;
    SYSCFG->EXTICR[3] &= ~SYSCFG_EXTICR4_EXTI13_Msk;
    SYSCFG->EXTICR[3] |= SYSCFG_EXTICR4_EXTI13_PC;
    EXTI->IMR1 |= EXTI_IMR1_IM10 | EXTI_IMR1_IM13;
    EXTI->FTSR1 |= EXTI_FTSR1_FT10 | EXTI_FTSR1_FT13;
    EXTI->RTSR1 &= ~(EXTI_RTSR1_RT10 | EXTI_RTSR1_RT13);
    EXTI->PR1 = EXTI_PR1_PIF10 | EXTI_PR1_PIF13;
    NVIC_SetPriority(EXTI15_10_IRQn, 5U);
    NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/* ---------------- USART2: PA2 TX, PA3 RX, AF7 ---------------- */
static void USART2_Init(void)
{
    RCC->APB1ENR1 |= RCC_APB1ENR1_USART2EN;
    (void)RCC->APB1ENR1;

    GPIOA->MODER &= ~((3UL << (2U * 2U)) | (3UL << (3U * 2U)));
    GPIOA->MODER |=  ((2UL << (2U * 2U)) | (2UL << (3U * 2U)));
    GPIOA->OTYPER &= ~((1UL << 2U) | (1UL << 3U));
    GPIOA->PUPDR &= ~((3UL << (2U * 2U)) | (3UL << (3U * 2U)));
    GPIOA->AFR[0] &= ~((0xFUL << (2U * 4U)) | (0xFUL << (3U * 4U)));
    GPIOA->AFR[0] |=  ((7UL << (2U * 4U)) | (7UL << (3U * 4U)));

    USART2->CR1 = 0U;
    USART2->CR2 = 0U;
    USART2->CR3 = 0U;
    USART2->BRR = (SYSCLK_HZ + (UART_BAUD / 2U)) / UART_BAUD;
    USART2->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void UART_SendString(const char *s)
{
    while (*s != '\0') {
        while ((USART2->ISR & USART_ISR_TXE) == 0U) {}
        USART2->TDR = (uint8_t)*s++;
    }
    while ((USART2->ISR & USART_ISR_TC) == 0U) {}
}

/* printf helper; float formatting requires toolchain support for printf float. */
#include <stdarg.h>
static void uart_printf(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    (void)vsnprintf(msg_buffer, sizeof(msg_buffer), fmt, args);
    va_end(args);
    UART_SendString(msg_buffer);
}


/* I2C1 LCD: PB8=SCL, PB9=SDA (Arduino D15/D14), AF4. */
static void I2C1_Init(void)
{
    RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN;
    RCC->APB1ENR1 |= RCC_APB1ENR1_I2C1EN;
    (void)RCC->APB1ENR1;
    GPIOB->MODER &= ~((3UL << 16U) | (3UL << 18U));
    GPIOB->MODER |=  ((2UL << 16U) | (2UL << 18U));
    GPIOB->OTYPER |= (1UL << 8U) | (1UL << 9U);
    GPIOB->OSPEEDR |= (3UL << 16U) | (3UL << 18U);
    GPIOB->PUPDR &= ~((3UL << 16U) | (3UL << 18U));
    GPIOB->AFR[1] &= ~((0xFUL << 0U) | (0xFUL << 4U));
    GPIOB->AFR[1] |= (4UL << 0U) | (4UL << 4U);
    I2C1->CR1 &= ~I2C_CR1_PE;
    I2C1->TIMINGR = 0x00100D14UL;
    I2C1->CR1 |= I2C_CR1_PE;
}
static bool LCD_I2C_Write(uint8_t value)
{
    uint32_t timeout = 100000U;
    while (I2C1->ISR & I2C_ISR_BUSY)
        if (--timeout == 0U) return false;
    I2C1->ICR = I2C_ICR_STOPCF | I2C_ICR_NACKCF | I2C_ICR_BERRCF |
                I2C_ICR_ARLOCF | I2C_ICR_OVRCF;
    I2C1->CR2 = (LCD_I2C_ADDR & I2C_CR2_SADD_Msk) |
                (1UL << I2C_CR2_NBYTES_Pos) | I2C_CR2_START | I2C_CR2_AUTOEND;
    timeout = 100000U;
    while ((I2C1->ISR & (I2C_ISR_TXIS | I2C_ISR_NACKF)) == 0U)
        if (--timeout == 0U) return false;
    if (I2C1->ISR & I2C_ISR_NACKF) {
        I2C1->ICR = I2C_ICR_NACKCF | I2C_ICR_STOPCF;
        return false;
    }
    I2C1->TXDR = value;
    timeout = 100000U;
    while ((I2C1->ISR & I2C_ISR_STOPF) == 0U)
        if (--timeout == 0U) return false;
    I2C1->ICR = I2C_ICR_STOPCF;
    return true;
}
static void LCD_Expander(uint8_t value) { (void)LCD_I2C_Write((uint8_t)(value | LCD_BACKLIGHT)); }
static void LCD_Pulse(uint8_t value)
{
    LCD_Expander((uint8_t)(value | LCD_EN)); delay_ms(1U);
    LCD_Expander((uint8_t)(value & (uint8_t)~LCD_EN)); delay_ms(1U);
}
static void LCD_SendNibble(uint8_t nibble, uint8_t rs)
{
    uint8_t v = (uint8_t)((nibble & 0xF0U) | rs | LCD_BACKLIGHT);
    LCD_Expander(v); LCD_Pulse(v);
}
static void LCD_Command(uint8_t cmd)
{
    LCD_SendNibble((uint8_t)(cmd & 0xF0U), 0U);
    LCD_SendNibble((uint8_t)((cmd << 4) & 0xF0U), 0U);
    if (cmd == 0x01U || cmd == 0x02U) delay_ms(2U);
}
static void LCD_Data(uint8_t data)
{
    LCD_SendNibble((uint8_t)(data & 0xF0U), LCD_RS);
    LCD_SendNibble((uint8_t)((data << 4) & 0xF0U), LCD_RS);
}
static void LCD_Init(void)
{
    delay_ms(50U);
    LCD_SendNibble(0x30U, 0U); delay_ms(5U);
    LCD_SendNibble(0x30U, 0U); delay_ms(2U);
    LCD_SendNibble(0x30U, 0U); delay_ms(2U);
    LCD_SendNibble(0x20U, 0U); delay_ms(2U);
    LCD_Command(0x28U); LCD_Command(0x0CU);
    LCD_Command(0x06U); LCD_Command(0x01U);
}
static void LCD_PrintLine(uint8_t row, const char *text)
{
    LCD_Command(row == 0U ? 0x80U : 0xC0U);
    for (uint8_t i = 0; i < 16U; i++) {
        if (text[i] == '\0') {
            for (; i < 16U; i++) LCD_Data(' ');
            break;
        }
        LCD_Data((uint8_t)text[i]);
    }
}
static void LCD_FormatModelError(char *out, size_t out_size,
                                 uint8_t cell_number, float error_v)
{
    if (error_v >= 10.0f) {
        (void)snprintf(out, out_size, "%u:+OVR", (unsigned)cell_number);
    } else if (error_v <= -10.0f) {
        (void)snprintf(out, out_size, "%u:-OVR", (unsigned)cell_number);
    } else {
        (void)snprintf(out, out_size, "%u:%+.2f", (unsigned)cell_number,
                       error_v);
    }
}
static void LCD_UpdateScreen(void)
{
    char l1[17] = {0}, l2[17] = {0};

    if (lcd_screen == 0U) {
        (void)snprintf(l1, sizeof(l1), "PK:%5.2fV M:%s", packVoltage,
                       mosfetState ? "ON" : "OFF");
        if (temperature > -100.0f)
            (void)snprintf(l2, sizeof(l2), "I:%4.2fA T:%4.1fC",
                           current, temperature);
        else
            (void)snprintf(l2, sizeof(l2), "I:%4.2fA T:ERR", current);
    } else if (lcd_screen == 1U) {
        (void)snprintf(l1, sizeof(l1), "CELL V 1:%4.2f", cell1);
        (void)snprintf(l2, sizeof(l2), "2:%4.2f 3:%4.2f", cell2, cell3);
    } else if (lcd_screen == 2U) {
        (void)snprintf(l1, sizeof(l1), "T:%s I:%s",
                       overTemperatureFault ? "FLT" : "OK",
                       overCurrentFault ? "FLT" : "OK");
        (void)snprintf(l2, sizeof(l2), "OV:%s UV:%s",
                       overVoltageFault ? "FLT" : "OK",
                       underVoltageFault ? "FLT" : "OK");
    } else {
        char e1[8], e2[8], e3[8];
        LCD_FormatModelError(e1, sizeof(e1), 1U, modelError[0]);
        LCD_FormatModelError(e2, sizeof(e2), 2U, modelError[1]);
        LCD_FormatModelError(e3, sizeof(e3), 3U, modelError[2]);
        (void)snprintf(l1, sizeof(l1), "%.7s %.7s", e1, e2);
        (void)snprintf(l2, sizeof(l2), "%.7s V", e3);
    }

    LCD_PrintLine(0U, l1);
    LCD_PrintLine(1U, l2);
}

/* ---------------- ADC1 ---------------- */
static void ADC1_Init(void)
{
    RCC->AHB2ENR |= RCC_AHB2ENR_ADCEN;
    (void)RCC->AHB2ENR;

    /* ADC clock from SYSCLK via synchronous clock mode /1. */
    ADC123_COMMON->CCR &= ~ADC_CCR_CKMODE_Msk;
    ADC123_COMMON->CCR |= ADC_CCR_CKMODE_0;

    if ((ADC1->CR & ADC_CR_DEEPPWD) != 0U) {
        ADC1->CR &= ~ADC_CR_DEEPPWD;
    }
    ADC1->CR |= ADC_CR_ADVREGEN;
    delay_ms(1);

    /* Calibrate while ADC is disabled. */
    ADC1->CR &= ~ADC_CR_ADEN;
    ADC1->CR |= ADC_CR_ADCAL;
    while ((ADC1->CR & ADC_CR_ADCAL) != 0U) {}

    ADC1->CFGR = 0U;       /* 12-bit, right aligned, software trigger, single conversion */
    ADC1->SQR1 = 0U;
    ADC1->SMPR1 = 0xFFFFFFFFUL; /* Long sample time on channels 0..9 */
    ADC1->SMPR2 = 0xFFFFFFFFUL; /* Long sample time on channels 10..18 */

    ADC1->ISR = ADC_ISR_ADRDY;
    ADC1->CR |= ADC_CR_ADEN;
    while ((ADC1->ISR & ADC_ISR_ADRDY) == 0U) {}
    ADC1->ISR = ADC_ISR_ADRDY;
}

static void ADC_SetChannel(uint32_t channel)
{
    /* One regular conversion, rank 1. */
    ADC1->SQR1 &= ~ADC_SQR1_L_Msk;
    ADC1->SQR1 &= ~ADC_SQR1_SQ1_Msk;
    ADC1->SQR1 |= ((channel << ADC_SQR1_SQ1_Pos) & ADC_SQR1_SQ1_Msk);
}

static uint16_t Read_ADC_Channel(uint32_t channel)
{
    ADC_SetChannel(channel);
    ADC1->ISR = ADC_ISR_EOC | ADC_ISR_EOS | ADC_ISR_OVR;
    ADC1->CR |= ADC_CR_ADSTART;

    uint32_t timeout = 1000000U;
    while ((ADC1->ISR & ADC_ISR_EOC) == 0U) {
        if (--timeout == 0U) {
            return 0U;
        }
    }

    uint16_t value = (uint16_t)ADC1->DR;
    return value;
}

static float readBatteryNode(uint32_t channel)
{
    uint32_t sum = 0U;
    for (int i = 0; i < 32; i++) {
        sum += Read_ADC_Channel(channel);
    }
    float adcValue = (float)sum / 32.0f;
    return (adcValue / ADC_MAX) * ADC_REF;
}

static float readCurrent(uint32_t channel)
{
    uint32_t sum = 0U;
    for (int i = 0; i < 64; i++) {
        sum += Read_ADC_Channel(channel);
    }
    float adcValue = (float)sum / 64.0f;
    float adcVoltage = (adcValue / ADC_MAX) * ADC_REF;
    return adcVoltage / SERIES_RESISTOR;
}

static float readTemperature(uint32_t channel)
{
    uint32_t sum = 0U;
    for (int i = 0; i < 32; i++) {
        sum += Read_ADC_Channel(channel);
    }

    float adcValue = (float)sum / 32.0f;
    float ntcVoltage = (adcValue / ADC_MAX) * ADC_REF;

    if (ntcVoltage <= 0.001f || ntcVoltage >= (ADC_REF - 0.001f)) {
        return -999.0f;
    }

    /* Assumes NTC is connected to ground and fixed resistor to 3.3 V. */
    float ntcResistance = NTC_FIXED_RESISTOR * ntcVoltage /
                          (ADC_REF - ntcVoltage);
    float temperatureKelvin =
        1.0f / ((1.0f / (NTC_NOMINAL_TEMPERATURE + 273.15f)) +
        (1.0f / NTC_BETA) *
        logf(ntcResistance / NTC_NOMINAL_RESISTANCE));

    return temperatureKelvin - 273.15f;
}

/* ---------------- SOC and battery model ---------------- */
static float voltageToSOC(float voltage)
{
    if (voltage >= 4.20f) return 100.0f;
    if (voltage >= 4.10f) return 90.0f + (voltage - 4.10f) * 100.0f;
    if (voltage >= 4.00f) return 80.0f + (voltage - 4.00f) * 100.0f;
    if (voltage >= 3.90f) return 60.0f + (voltage - 3.90f) * 200.0f;
    if (voltage >= 3.80f) return 40.0f + (voltage - 3.80f) * 200.0f;
    if (voltage >= 3.70f) return 20.0f + (voltage - 3.70f) * 200.0f;
    if (voltage >= 3.60f) return 10.0f + (voltage - 3.60f) * 100.0f;
    if (voltage >= 3.50f) return 5.0f + (voltage - 3.50f) * 50.0f;
    if (voltage >= 3.00f) return (voltage - 3.00f) * 10.0f;
    return 0.0f;
}

static float SOC_to_OCV(float soc)
{
    static const float socTable[] =
        {0, 5, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    static const float ocvTable[] =
        {3.000f, 3.300f, 3.500f, 3.620f, 3.680f, 3.720f,
         3.750f, 3.790f, 3.850f, 3.950f, 4.100f, 4.200f};

    if (soc <= socTable[0]) return ocvTable[0];
    if (soc >= socTable[11]) return ocvTable[11];

    for (int i = 0; i < 11; i++) {
        if (soc <= socTable[i + 1]) {
            float ratio = (soc - socTable[i]) /
                          (socTable[i + 1] - socTable[i]);
            return ocvTable[i] + ratio * (ocvTable[i + 1] - ocvTable[i]);
        }
    }
    return ocvTable[11];
}

static void UpdateBatteryModel(float current_A, float dt)
{
    if (dt <= 0.0f) return;

    float a = expf(-dt / MODEL_TAU);
    float b = MODEL_R1 * (1.0f - a);
    float measured[3] = {cell1, cell2, cell3};

    for (int i = 0; i < 3; i++) {
        /* Positive current = discharge; negative current = charge. */
        socCell[i] -= (current_A * dt / BATTERY_CAPACITY_C) * 100.0f;
        if (socCell[i] > 100.0f) socCell[i] = 100.0f;
        if (socCell[i] < 0.0f) socCell[i] = 0.0f;

        ocvCell[i] = SOC_to_OCV(socCell[i]);
        vRC[i] = a * vRC[i] + b * current_A;
        vModel[i] = ocvCell[i] - current_A * MODEL_R0 - vRC[i];
        modelError[i] = measured[i] - vModel[i];
        modelErrorAbs[i] = fabsf(modelError[i]);
    }

    socPack = (socCell[0] + socCell[1] + socCell[2]) / 3.0f;
}

/* ---------------- Main ---------------- */
int main(void)
{
    SystemClock_Config();
    GPIO_Init();
    USART2_Init();
    I2C1_Init();
    LCD_Init();
    ADC1_Init();

    mosfetState = false;
    userToggleState = false;
    MOSFET_GPIO->BSRR = (1UL << (MOSFET_PIN + 16U));
    delay_ms(1000);

    UART_SendString("\r\n========================================\r\n"
                    "STM32 3S BMS - BARE METAL\r\n"
                    "========================================\r\n"
                    "MOSFET OUTPUT (D13/PA5; LD2 follows) = OFF\r\n\r\n");

    B1 = readBatteryNode(B1_CHANNEL) * SCALE_B1;
    B2 = readBatteryNode(B2_CHANNEL) * SCALE_B2;
    B3 = readBatteryNode(B3_CHANNEL) * SCALE_B3;

    cell1 = B1 - B2;
    cell2 = B2 - B3;
    cell3 = B3;
    packVoltage = cell1 + cell2 + cell3;

    socCell[0] = voltageToSOC(cell1);
    socCell[1] = voltageToSOC(cell2);
    socCell[2] = voltageToSOC(cell3);
    socPack = (socCell[0] + socCell[1] + socCell[2]) / 3.0f;

    for (int i = 0; i < 3; i++) {
        vRC[i] = 0.0f;
        ocvCell[i] = SOC_to_OCV(socCell[i]);
        vModel[i] = ocvCell[i];
        modelError[i] = 0.0f;
        modelErrorAbs[i] = 0.0f;
    }

    lastModelTime = millis();
    lastModelUpdate = lastModelTime;
    modelInitialized = true;

    uint32_t lastModelPrint = 0U;
    uint32_t lastReport = 0U;

    while (1) {
        B1 = readBatteryNode(B1_CHANNEL) * SCALE_B1;
        B2 = readBatteryNode(B2_CHANNEL) * SCALE_B2;
        B3 = readBatteryNode(B3_CHANNEL) * SCALE_B3;

        cell1 = B1 - B2;
        cell2 = B2 - B3;
        cell3 = B3;
        packVoltage = cell1 + cell2 + cell3;

        current = readCurrent(CURRENT_CHANNEL);
        temperature = readTemperature(NTC_CHANNEL);

        uint32_t now = millis();
        if (modelInitialized &&
            (uint32_t)(now - lastModelUpdate) >= MODEL_UPDATE_MS) {
            float dt = (uint32_t)(now - lastModelTime) / 1000.0f;
            lastModelTime = now;
            lastModelUpdate = now;
            UpdateBatteryModel(current, dt);
        }

        /* Protection flags with hysteresis, matching original logic. */
        if (temperature > -100.0f) {
            if (temperature >= OVER_TEMPERATURE) overTemperatureFault = true;
            else if (temperature <= TEMPERATURE_RECOVERY)
                overTemperatureFault = false;
        } else {
            overTemperatureFault = true;
        }

        if (current >= OVER_CURRENT) overCurrentFault = true;
        else if (current < OVER_CURRENT * 0.9f) overCurrentFault = false;

        if (cell1 >= CELL_OVER_VOLTAGE ||
            cell2 >= CELL_OVER_VOLTAGE ||
            cell3 >= CELL_OVER_VOLTAGE) {
            overVoltageFault = true;
        } else if (cell1 <= CELL_OV_RECOVERY &&
                   cell2 <= CELL_OV_RECOVERY &&
                   cell3 <= CELL_OV_RECOVERY) {
            overVoltageFault = false;
        }

        if (cell1 <= CELL_UNDER_VOLTAGE ||
            cell2 <= CELL_UNDER_VOLTAGE ||
            cell3 <= CELL_UNDER_VOLTAGE) {
            underVoltageFault = true;
        } else if (cell1 >= CELL_UV_RECOVERY &&
                   cell2 >= CELL_UV_RECOVERY &&
                   cell3 >= CELL_UV_RECOVERY) {
            underVoltageFault = false;
        }

        /*
         * Preserves the source behavior: user button alone controls PA5.
         * Fault flags do NOT inhibit the output in the supplied program.
         * For actual battery protection, add a verified hardware-safe interlock.
         */
        mosfetState = userToggleState;
        if (mosfetState) MOSFET_GPIO->BSRR = (1UL << MOSFET_PIN);
        else MOSFET_GPIO->BSRR = (1UL << (MOSFET_PIN + 16U));

        static uint32_t lastLCDUpdate = 0U;
        if ((uint32_t)(now - lastLCDUpdate) >= 250U) {
            lastLCDUpdate = now;
            LCD_UpdateScreen();
        }

        if ((uint32_t)(now - lastReport) >= 500U) {
            lastReport = now;
            uart_printf("\r\n========== BMS ==========\r\n"
                        "NODE1: %.2fV | NODE2: %.2fV | NODE3: %.2fV\r\n"
                        "CELL1: %.2fV | CELL2: %.2fV | CELL3: %.2fV\r\n"
                        "PACK: %.2fV | SOC: %.1f%%\r\n",
                        B1, B2, B3, cell1, cell2, cell3, packVoltage, socPack);

            if (temperature > -100.0f)
                uart_printf("CURRENT: %.3f A | TEMP: %.1f C\r\n",
                            current, temperature);
            else
                uart_printf("CURRENT: %.3f A | TEMP: ERROR\r\n", current);

            uart_printf("PROT: TEMP %s | CUR %s | OV %s | UV %s\r\n",
                        overTemperatureFault ? "FAULT" : "OK",
                        overCurrentFault ? "FAULT" : "OK",
                        overVoltageFault ? "FAULT" : "OK",
                        underVoltageFault ? "FAULT" : "OK");

            uart_printf("MOSFET OUTPUT: %s\r\n==========================\r\n",
                        mosfetState ? "ON" : "OFF");
        }

        if ((uint32_t)(now - lastModelPrint) >= 200U) {
            lastModelPrint = now;
            uart_printf("MODEL: V1=%.3f E1=%+.3f | V2=%.3f E2=%+.3f | "
                        "V3=%.3f E3=%+.3f\r\n",
                        vModel[0], modelError[0],
                        vModel[1], modelError[1],
                        vModel[2], modelError[2]);
        }


    }
}
