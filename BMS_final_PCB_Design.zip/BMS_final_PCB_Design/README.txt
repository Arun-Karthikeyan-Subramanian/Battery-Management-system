BMS01_PCB - PCB design release

Editable KiCad project
- BMS01_PCB.kicad_pcb: routed four-layer board
- BMS01_PCB.kicad_pro and BMS01_PCB.kicad_sch: project and schematic copy
- BMS01_PCB.kicad_dru: added design rule for the 1.0 mm Q6-to-R25 current route
- fp-lib-table, sym-lib-table, SAKA_FP.pretty: project-local libraries and custom switch footprint
- BMS01_PCB_final_drc.json: final full-check DRC report

Design basis
- Maximum voltage: 15 V
- Maximum current used for layout: 1.5 A
- Four copper layers, 1.6 mm FR-4; standard Robu stack-up assumption is 1 oz outer and 0.5 oz inner copper
- Board outline: 138 x 128 mm
- GND pours on In1.Cu and B.Cu
- Q6-to-R25 current path: 1.0 mm on F.Cu; separate 0.2 mm ADC sense branch
- General minimum track width: 0.10 mm; clearance: 0.20 mm; PTH-to-copper: 0.33 mm; hole-to-hole: 0.50 mm; copper-to-edge: 0.50 mm
- Via: 0.60 mm diameter with 0.30 mm drill; project minimums are 0.45 mm diameter and 0.20 mm drill

Manufacturing
- BMS01_PCB_Robu_Gerbers.zip contains the copper, mask, paste, silkscreen, board outline, Gerber job, and separate PTH/NPTH drill files.
- Full files and drill maps are also in manufacturing/.
- Check the fabricator quote against the supplied 4-layer stack-up before ordering.

DRC and assembly notes
- Final KiCad 10.0.6 DRC: 0 violations, 0 unconnected items, 0 schematic parity issues, and 0 ignored checks. All checks are enabled in the project.
- The SW6 footprint is through-hole and its footprint metadata now matches its plated pads.
- Several crowded reference designators are on F.Fab rather than F.Silkscreen so the silkscreen remains clear. The review PDF includes F.Fab for assembly reference.
- R25 is 0.667 ohm in the supplied schematic. At 1.5 A it dissipates 1.50 W (I^2R). Select a resistor rated at least 2 W after checking temperature derating and airflow.
- The board is saved in KiCad 10 format.

Fabrication reference: Robu PCB Manufacturing Capabilities, https://robu.in/pcb-manufacturing-capabilities/
