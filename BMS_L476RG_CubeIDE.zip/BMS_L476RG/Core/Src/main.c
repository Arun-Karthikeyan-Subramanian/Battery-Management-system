/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADC_MAX 4095.0f
#define ADC_REF 3.3f
#define SCALE_B1 4.4036f
#define SCALE_B2 3.0373f
#define SCALE_B3 1.5243f
#define SERIES_RESISTOR 0.78125f
#define NTC_FIXED_RESISTOR 10000.0f
#define NTC_NOMINAL_RESISTANCE 10000.0f
#define NTC_NOMINAL_TEMPERATURE 25.0f
#define NTC_BETA 3950.0f
#define OVER_TEMPERATURE 40.0f
#define TEMPERATURE_RECOVERY 38.0f
#define OVER_CURRENT 0.5f
#define CELL_OVER_VOLTAGE 4.20f
#define CELL_OV_RECOVERY 4.15f
#define CELL_UNDER_VOLTAGE 3.00f
#define CELL_UV_RECOVERY 3.10f
#define BATTERY_CAPACITY_AH 2.0f
#define BATTERY_CAPACITY_C (BATTERY_CAPACITY_AH*3600.0f)
#define MODEL_UPDATE_MS 10U
#define MODEL_R0 0.018504f
#define MODEL_R1 0.0172f
#define MODEL_C1 22.7f
#define MODEL_TAU (MODEL_R1*MODEL_C1)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
bool userToggleState=false;
bool mosfetState=true;
bool overTemperatureFault=false;
bool overCurrentFault=false;
bool overVoltageFault=false;
bool underVoltageFault=false;
float socPack=100.0f;
char msg_buffer[256];
float B1,B2,B3;
float cell1,cell2,cell3;
float packVoltage,current,temperature;
float socCell[3]={0.0f,0.0f,0.0f};
float vRC[3]={0.0f,0.0f,0.0f};
float ocvCell[3]={0.0f,0.0f,0.0f};
float vModel[3]={0.0f,0.0f,0.0f};
float modelError[3]={0.0f,0.0f,0.0f};
float modelErrorAbs[3]={0.0f,0.0f,0.0f};
uint32_t lastModelTime=0;
uint32_t lastModelUpdate=0;
bool modelInitialized=false;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
/* USER CODE BEGIN PFP */
uint16_t Read_ADC_Channel(uint32_t channel);
float readBatteryNode(uint32_t channel);
float readCurrent(uint32_t channel);
float readTemperature(uint32_t channel);
float voltageToSOC(float voltage);
float SOC_to_OCV(float soc);
void UpdateBatteryModel(float current,float dt);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
  mosfetState=false;
  userToggleState=false;
  HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_RESET);
  HAL_Delay(1000);
  char *startup_msg="\r\n========================================\r\nSTM32 3S BMS START\r\n========================================\r\nMOSFET = OFF\r\n\r\n";
  HAL_UART_Transmit(&huart2,(uint8_t*)startup_msg,strlen(startup_msg),1000);

  B1=readBatteryNode(ADC_CHANNEL_5)*SCALE_B1;
  B2=readBatteryNode(ADC_CHANNEL_6)*SCALE_B2;
  B3=readBatteryNode(ADC_CHANNEL_9)*SCALE_B3;

  cell1=B1-B2;
  cell2=B2-B3;
  cell3=B3;
  packVoltage=cell1+cell2+cell3;

  socCell[0]=voltageToSOC(cell1);
  socCell[1]=voltageToSOC(cell2);
  socCell[2]=voltageToSOC(cell3);
  socPack=(socCell[0]+socCell[1]+socCell[2])/3.0f;

  for(int i=0;i<3;i++)
  {
      vRC[i]=0.0f;
      ocvCell[i]=SOC_to_OCV(socCell[i]);
      vModel[i]=ocvCell[i];
      modelError[i]=0.0f;
      modelErrorAbs[i]=0.0f;
  }

  lastModelTime=HAL_GetTick();
  lastModelUpdate=lastModelTime;
  modelInitialized=true;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  // 1. BATTERY VOLTAGE MEASUREMENTS
	  B1=readBatteryNode(ADC_CHANNEL_5)*SCALE_B1;
	  B2=readBatteryNode(ADC_CHANNEL_6)*SCALE_B2;
	  B3=readBatteryNode(ADC_CHANNEL_9)*SCALE_B3;

	  cell1=B1-B2;
	  cell2=B2-B3;
	  cell3=B3;
	  packVoltage=cell1+cell2+cell3;

	  // 2. CURRENT AND TEMPERATURE
	  current=readCurrent(ADC_CHANNEL_1);
	  temperature=readTemperature(ADC_CHANNEL_2);

	  // 3. BATTERY MATHEMATICAL MODEL
	  uint32_t now=HAL_GetTick();
	  if(modelInitialized&&(uint32_t)(now-lastModelUpdate)>=MODEL_UPDATE_MS)
	  {
	      float dt=(uint32_t)(now-lastModelTime)/1000.0f;
	      lastModelTime=now;
	      lastModelUpdate=now;
	      UpdateBatteryModel(current,dt);
	  }

	  // 4. PROTECTION STATUS DETECTION
	  if(temperature>-100.0f)
	  {
	      if(temperature>=OVER_TEMPERATURE)overTemperatureFault=true;
	      else if(temperature<=TEMPERATURE_RECOVERY)overTemperatureFault=false;
	  }
	  else
	  {
	      overTemperatureFault=true;
	  }

	  if(current>=OVER_CURRENT)overCurrentFault=true;
	  else if(current<OVER_CURRENT*0.9f)overCurrentFault=false;

	  if(cell1>=CELL_OVER_VOLTAGE||cell2>=CELL_OVER_VOLTAGE||cell3>=CELL_OVER_VOLTAGE)
	      overVoltageFault=true;
	  else if(cell1<=CELL_OV_RECOVERY&&cell2<=CELL_OV_RECOVERY&&cell3<=CELL_OV_RECOVERY)
	      overVoltageFault=false;

	  if(cell1<=CELL_UNDER_VOLTAGE||cell2<=CELL_UNDER_VOLTAGE||cell3<=CELL_UNDER_VOLTAGE)
	      underVoltageFault=true;
	  else if(cell1>=CELL_UV_RECOVERY&&cell2>=CELL_UV_RECOVERY&&cell3>=CELL_UV_RECOVERY)
	      underVoltageFault=false;

	  // 5. MOSFET CONTROL
	  mosfetState=userToggleState;
	  if(mosfetState)HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_SET);
	  else HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,GPIO_PIN_RESET);

	  // 6. UART MONITORING
	  sprintf(msg_buffer,"\r\n========== BMS ==========\r\nNODE1: %.2fV | NODE2: %.2fV | NODE3: %.2fV\r\nCELL1: %.2fV | CELL2: %.2fV | CELL3: %.2fV\r\nPACK: %.2fV | SOC: %.1f%%\r\n",B1,B2,B3,cell1,cell2,cell3,packVoltage,socPack);
	  HAL_UART_Transmit(&huart2,(uint8_t*)msg_buffer,strlen(msg_buffer),100);

	  if(temperature>-100.0f)
	      sprintf(msg_buffer,"CURRENT: %.3f | TEMP: %.1f C\r\n",current,temperature);
	  else
	      sprintf(msg_buffer,"CURRENT: %.3f | TEMP: ERROR\r\n",current);
	  HAL_UART_Transmit(&huart2,(uint8_t*)msg_buffer,strlen(msg_buffer),100);

	  sprintf(msg_buffer,"PROT: TEMP %s | CUR %s | OV %s | UV %s\r\n",overTemperatureFault?"FAULT":"OK",overCurrentFault?"FAULT":"OK",overVoltageFault?"FAULT":"OK",underVoltageFault?"FAULT":"OK");
	  HAL_UART_Transmit(&huart2,(uint8_t*)msg_buffer,strlen(msg_buffer),100);

	  sprintf(msg_buffer,"MOSFET: %s\r\n==========================\r\n",mosfetState?"ON":"OFF");
	  HAL_UART_Transmit(&huart2,(uint8_t*)msg_buffer,strlen(msg_buffer),100);

	  // 7. MATHEMATICAL MODEL OUTPUT EVERY 200 ms
	  static uint32_t lastModelPrint=0;
	  uint32_t printTime=HAL_GetTick();
	  if((uint32_t)(printTime-lastModelPrint)>=200U)
	  {
	      lastModelPrint=printTime;
	      sprintf(msg_buffer,"MODEL: V1=%.3f E1=%+.3f | V2=%.3f E2=%+.3f | V3=%.3f E3=%+.3f\r\n",vModel[0],modelError[0],vModel[1],modelError[1],vModel[2],modelError[2]);
	      HAL_UART_Transmit(&huart2,(uint8_t*)msg_buffer,strlen(msg_buffer),100);
	  }

	  // 8. PC13 BUTTON
	  static GPIO_PinState last_btn_state=GPIO_PIN_SET;
	  GPIO_PinState current_btn_state=HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13);
	  if(last_btn_state==GPIO_PIN_SET&&current_btn_state==GPIO_PIN_RESET)
	  {
	      userToggleState=!userToggleState;
	      HAL_Delay(50);
	  }
	  last_btn_state=current_btn_state;
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_MODE_INDEPENDENT;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_2;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_247CYCLES_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void UpdateBatteryModel(float current,float dt)
{
    if(dt<=0.0f)return;
    float a=expf(-dt/MODEL_TAU);
    float b=MODEL_R1*(1.0f-a);
    float measured[3]={cell1,cell2,cell3};

    for(int i=0;i<3;i++)
    {
        // Positive current = discharge; negative current = charge
        socCell[i]-=(current*dt/BATTERY_CAPACITY_C)*100.0f;
        if(socCell[i]>100.0f)socCell[i]=100.0f;
        if(socCell[i]<0.0f)socCell[i]=0.0f;

        ocvCell[i]=SOC_to_OCV(socCell[i]);
        vRC[i]=a*vRC[i]+b*current;
        vModel[i]=ocvCell[i]-current*MODEL_R0-vRC[i];
        modelError[i]=measured[i]-vModel[i];
        modelErrorAbs[i]=fabsf(modelError[i]);
    }

    socPack=(socCell[0]+socCell[1]+socCell[2])/3.0f;
}

uint16_t Read_ADC_Channel(uint32_t channel)
{
    ADC_ChannelConfTypeDef sConfig={0};
    sConfig.Channel=channel;
    sConfig.Rank=ADC_REGULAR_RANK_1;
    sConfig.SamplingTime=ADC_SAMPLETIME_247CYCLES_5;
    sConfig.SingleDiff=ADC_SINGLE_ENDED;
    sConfig.OffsetNumber=ADC_OFFSET_NONE;
    sConfig.Offset=0;

    if(HAL_ADC_ConfigChannel(&hadc1,&sConfig)!=HAL_OK)return 0;
    if(HAL_ADC_Start(&hadc1)!=HAL_OK)return 0;
    if(HAL_ADC_PollForConversion(&hadc1,10)!=HAL_OK)
    {
        HAL_ADC_Stop(&hadc1);
        return 0;
    }

    uint16_t val=(uint16_t)HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);
    return val;
}

float readBatteryNode(uint32_t channel)
{
    uint32_t sum=0;
    for(int i=0;i<32;i++)
    {
        sum+=Read_ADC_Channel(channel);
    }
    float adcValue=sum/32.0f;
    return (adcValue/ADC_MAX)*ADC_REF;
}

float readCurrent(uint32_t channel)
{
    uint32_t sum=0;
    for(int i=0;i<64;i++)
    {
        sum+=Read_ADC_Channel(channel);
    }

    float adcValue=sum/64.0f;
    float adcVoltage=(adcValue/ADC_MAX)*ADC_REF;

    // This calculates voltage only. Convert to amperes using
    // the actual current-sensing circuit and shunt resistance.
    float current=adcVoltage/SERIES_RESISTOR;
    return current;
}

float readTemperature(uint32_t channel)
{
    uint32_t sum=0;
    for(int i=0;i<32;i++)
    {
        sum+=Read_ADC_Channel(channel);
    }

    float adcValue=sum/32.0f;
    float ntcVoltage=(adcValue/ADC_MAX)*ADC_REF;

    if(ntcVoltage<=0.001f||ntcVoltage>=(ADC_REF-0.001f))return -999.0f;

    float ntcResistance=NTC_FIXED_RESISTOR*ntcVoltage/(ADC_REF-ntcVoltage);
    float temperatureKelvin=1.0f/((1.0f/(NTC_NOMINAL_TEMPERATURE+273.15f))+(1.0f/NTC_BETA)*logf(ntcResistance/NTC_NOMINAL_RESISTANCE));
    return temperatureKelvin-273.15f;
}

float voltageToSOC(float voltage)
{
    if(voltage>=4.20f)return 100.0f;
    if(voltage>=4.10f)return 90.0f+(voltage-4.10f)*100.0f;
    if(voltage>=4.00f)return 80.0f+(voltage-4.00f)*100.0f;
    if(voltage>=3.90f)return 60.0f+(voltage-3.90f)*200.0f;
    if(voltage>=3.80f)return 40.0f+(voltage-3.80f)*200.0f;
    if(voltage>=3.70f)return 20.0f+(voltage-3.70f)*200.0f;
    if(voltage>=3.60f)return 10.0f+(voltage-3.60f)*100.0f;
    if(voltage>=3.50f)return 5.0f+(voltage-3.50f)*50.0f;
    if(voltage>=3.00f)return (voltage-3.00f)*10.0f;
    return 0.0f;
}

float SOC_to_OCV(float soc)
{
    static const float socTable[]={0,5,10,20,30,40,50,60,70,80,90,100};
    static const float ocvTable[]={3.000f,3.300f,3.500f,3.620f,3.680f,3.720f,3.750f,3.790f,3.850f,3.950f,4.100f,4.200f};

    if(soc<=socTable[0])return ocvTable[0];
    if(soc>=socTable[11])return ocvTable[11];

    for(int i=0;i<11;i++)
    {
        if(soc<=socTable[i+1])
        {
            float ratio=(soc-socTable[i])/(socTable[i+1]-socTable[i]);
            return ocvTable[i]+ratio*(ocvTable[i+1]-ocvTable[i]);
        }
    }
    return ocvTable[11];
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
